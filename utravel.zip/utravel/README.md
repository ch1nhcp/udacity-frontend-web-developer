# FEND Udacity Capstone - UTravel App

A travel app designed to provide weather predictions and pictures for a specified destination.

### Technologies

This project uses the following technologies

- Webserver: Node
- Build tool: Webpack
- External script: Service Worker
- External APIs: Geonames, Weatherbit, Pixabay

## Table of Contents

- [Getting Started](#getting-started)
- [Running Tests](#running-tests)
- [Author](#author)

## Getting Started

To get a local copy up and running, follow these steps:

Install NPM packages:
`sh
    npm install
    `
Create accounts for external APIs and add the api keys to a `.env` file:

```
    GEONAMES_USERNAME = **********
    WEATHERBIT_API_KEY = **********
    PIXABAY_API_KEY = **********
```

Build the project:
`sh
    npm run build-prod
    `
Start the server:
`sh
    npm start
    `
Open your web browser and navigate to `http://localhost:3000`.

## Running Tests

Run `npm test` in the project directory to run the Jest tests.

## Author

Pham Chinh

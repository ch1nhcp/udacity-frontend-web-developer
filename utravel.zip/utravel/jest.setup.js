import fetchMock from "jest-fetch-mock";

fetchMock.enableMocks();

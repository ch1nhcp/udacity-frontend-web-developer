import { updateUI } from "./updateUI";
import { checkForName } from "./nameChecker";

async function handleSubmit(event) {
  event.preventDefault();

  // check what text was put into the form field
  let formText = document.getElementById("name").value;

  if (checkForName(formText)) {
    alert("Invalid name! Please try again.");
  } else {
    await getData("http://localhost:8080/call", {
      data: formText,
    })
      .then((apiData) => apiData.json())
      .then((data) => {
        console.log(data);
        updateUI(data);
      });
  }
}

async function getData(url, userInput) {
  let response = await fetch(url, {
    method: "POST",
    credentials: "same-origin",
    headers: {
      "Content-Type": "application/json",
    },
    // Body data type must match "Content-Type" header
    body: JSON.stringify(userInput),
  });

  return response;
}

export { handleSubmit };

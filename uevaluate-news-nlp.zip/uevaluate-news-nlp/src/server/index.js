const dotenv = require("dotenv");
dotenv.config();

console.log(`Your API key is ${process.env.API_KEY}`);

const path = require("path");
const express = require("express");
const mockAPIResponse = require("./mockAPI.js");

// Cors for cross origin allowance
const cors = require("cors");
app.use(cors());

// Step 4: declare API credentials
const { MeaningCloud } = require("meaningcloud-sdk");
var textapi = new MeaningCloud({
  // application_key: "your-key"
  application_key: process.env.MEANINGCLOUD_API_KEY,
});

const app = express();

app.use(express.static("dist"));

// Routes
app.get("/", function (req, res) {
  res.sendFile(path.resolve("dist/index.html"));
});

app.listen(8080, function () {
  console.log("Example app listening on port 8080!");
});

app.get("/test", function (req, res) {
  res.send(mockAPIResponse);
});

app.post("/callapi", callAPI);

async function callAPI(req, res) {
  const formdata = new FormData();
  formdata.append("key", process.env.API_KEY);
  formdata.append("txt", req.body.data);
  formdata.append("lang", "en");

  const requestOptions = {
    method: "POST",
    body: formdata,
    redirect: "follow",
  };

  try {
    const response = await fetch(
      "https://api.meaningcloud.com/lang-4.0/identification",
      requestOptions
    );
    const data = await response.json();
    console.log(data);
    res.send(data);
  } catch (error) {
    console.log("error", error);
    res.status(500).send("An error occurred!");
  }
}

/**
 *
 * Manipulating the DOM exercise.
 * Exercise programmatically builds navigation,
 * scrolls to anchors from navigation,
 * and highlights section in viewport upon scrolling.
 *
 * Dependencies: None
 *
 * JS Version: ES2015/ES6
 *
 * JS Standard: ESlint
 *
 */

/**
 * Comments should be present at the beginning of each procedure and class.
 * Great to have comments before crucial code sections within the procedure.
 */

/**
 * Define Global Variables
 *
 */
// Generate and select section Variables
const sections = ["section1", "section2", "section3", "section4", "section5"];
const navList = document.querySelector("#navbar__list");
const sectionElements = {};

sections.forEach((section) => {
  sectionElements[section] = document.querySelector(`#${section}`);
});

/**
 * End Global Variables
 * Start Helper Functions
 *
 */
// build the nav bar
sections.forEach((section, index) => {
  const menuItem = document.createElement("li");

  //create Links
  const a = document.createElement("a");
  const linkText = document.createTextNode(`Section ${index + 1}`);
  a.appendChild(linkText);
  a.href = `#${section}`;
  a.className = "menu__link";

  menuItem.appendChild(a);

  navList.appendChild(menuItem);
});
/**
 * End Helper Functions
 * Begin Main Functions
 *
 */

// Add class 'active' to section when near top of viewport
function setActive() {
  const sections = [section1, section2, section3, section4, section5];
  const threshold = 150;

  for (const section of sections) {
    const sectionRect = section.getBoundingClientRect();
    const navLink = document.querySelector(
      `a[href="#${section.id}"]`
    ).parentElement;

    if (sectionRect.top <= threshold && sectionRect.bottom >= threshold) {
      section.classList.add("your-active-class");
      navLink.classList.add("active");
    } else {
      section.classList.remove("your-active-class");
      navLink.classList.remove("active");
    }
  }
}

// Scroll to section on link click
document.addEventListener("scroll", function () {
  setActive();
});

// Set sections status active
const links = document.querySelectorAll(".menu__link");

links.forEach((link) => {
  link.addEventListener("click", function () {
    const current = document.querySelector(".active");
    if (current) current.classList.remove("active");

    this.closest("li").classList.add("active");
  });
});

/**
 * End Main Functions
 * Begin Events
 *
 */

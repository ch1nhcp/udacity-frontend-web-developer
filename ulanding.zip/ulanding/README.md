# Landing Page Project

## Project's Description
This project demonstrates smooth scrolling and active navigation functionality using HTML, CSS, and JavaScript. It is single-page website with multiple sections where the navigation menu dynamically updates as the user scrolls through the sections.

- [Instructions](#instructions)
- [Installation](#installation)
- [To-do](#to-do)
- [Demo](#demo)

## Instructions

The starter project has some HTML and CSS styling to display a static version of the Landing Page project. You'll need to convert this project from a static project to an interactive one. This will require modifying the HTML and CSS files, but primarily the JavaScript file.

To get started, open `js/app.js` and start building out the app's functionality

For specific, detailed instructions, look at the project instructions in the Udacity Classroom.

# Installation
This project does not require installing any libraries

# To-do
- Create new section
- Create the nav bar
- Add class "active" when user scroll through the sections
- Check responsive

# Demo
![Alt text](image/screenshot.png)

[(Back to top)](#instructions)

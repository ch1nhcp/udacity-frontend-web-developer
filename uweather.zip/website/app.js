/* Global Variables */
// Personal API Key for OpenWeatherMap API for test purpose
// const apiKey = "b1612913fae55dddd4cefc6564ab6fae&units=imperial";

const apiKey = "<api-key>&units=imperial";
const baseURL = "https://api.openweathermap.org/data/2.5/weather";

const urlServer = "http://localhost:8000";

// Event listener to add function to existing HTML DOM element
const zipCode = document.querySelector("#zip");
const feelings = document.querySelector("#feelings");
const generateButton = document.querySelector("#generate");

const place = document.querySelector("#place");
const date = document.querySelector("#date");
const temp = document.querySelector("#temp");
const content = document.querySelector("#content");

// Create a new date instance dynamically with JS
let d = new Date();
let newDate = d.getMonth() + "." + d.getDate() + "." + d.getFullYear();

// Event Listener for Generate Button
generateButton.addEventListener("click", function () {
  getWeatherData(baseURL, zipCode.value, apiKey).then(function (data) {
    postData(`${urlServer}/add`, {
      temp: data.main.temp,
      feeling: feelings.value,
      date: newDate,
      place: data.name,
    });
    updateUI();
  });
});

/* Function to GET Web API Data*/
const getWeatherData = async (baseURL, zipCode, apiKey) => {
  const res = await fetch(`${baseURL}?zip=${zipCode},us&appid=${apiKey}`);
  try {
    const data = await res.json();
    return data;
  } catch (error) {
    console.log("error", error);
  }
};

/* Function to POST data */
const postData = async (url = "", data = {}) => {
  console.log(data);
  const response = await fetch(url, {
    method: "POST",
    credentials: "same-origin",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify(data),
  });

  try {
    const newData = await response.json();
    console.log(newData);
    return newData;
  } catch (error) {
    console.log("error", error);
  }
};

/* Function to GET Project Data and Update UI */
const updateUI = async () => {
  const request = await fetch(`${urlServer}/all`, { method: "GET" });
  try {
    const data = await request.json();
    console.log("Update UI data:", data);

    place.innerHTML = data.place;
    temp.innerHTML =
      Math.round(data.temp) +
      " °F -" +
      Math.round(((data.temp - 32) * 5) / 9) +
      " °C";
    content.innerHTML = data.feeling;
    date.innerHTML = data.date;
    return data;
  } catch (error) {
    console.log("error", error);
  }
};
